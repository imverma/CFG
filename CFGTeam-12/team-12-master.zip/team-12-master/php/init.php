<?php

$user="root";
$password="";
$host="localhost";
$db_name="annadhan";
$con=mysqli_connect($host,$user,$password,$db_name);
?>